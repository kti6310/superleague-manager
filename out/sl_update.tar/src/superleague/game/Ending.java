package superleague.game;

import superleague.model.Player;
import superleague.model.Team;

public record Ending(String title, String description, boolean starStays, Player star) {

    public static Ending decide(Team team, int rank) {
        int diff = team.tier().targetRank() - rank;
        int morale = team.morale();
        Player star = team.starPlayer();
        boolean starStays = morale >= 0;

        if (rank == 1) {
            return new Ending("초대 챔피언",
                    "슈퍼리그 첫 시즌 우승. 구단 역사에 이름을 남기고 장기 재계약을 제안받았습니다.", starStays, star);
        }
        if (diff >= 3 && morale >= 20) {
            return new Ending("기적의 시즌",
                    "등급을 뛰어넘는 성적과 단단한 선수단. 운영진이 장기 재계약과 특별 보너스를 약속했습니다.", starStays, star);
        }
        if (diff >= 0 && morale < -30) {
            return new Ending("이긴 시즌, 잃은 라커룸",
                    "목표는 달성했지만 선수단의 신뢰를 잃었습니다. 운영진은 1년 연장만 제안했습니다.", starStays, star);
        }
        if (diff >= 0) {
            return new Ending("재계약",
                    "운영진의 목표를 달성했습니다. 다음 시즌도 지휘봉을 잡습니다.", starStays, star);
        }
        if (diff >= -2) {
            return new Ending("유임, 그러나 경고",
                    "목표에 조금 못 미쳤습니다. 다음 시즌 초반 성적이 거취를 결정합니다.", starStays, star);
        }
        return new Ending("경질",
                "운영진의 기대에 크게 못 미쳤습니다. 시즌 종료와 함께 경질됐습니다.", starStays, star);
    }
}
